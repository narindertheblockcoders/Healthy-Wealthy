import React from 'react'
import Footer from '../Component/ui/Footer'

const footer = () => {
  return (
    <div>
        <Footer/>
    </div>
  )
}

export default footer