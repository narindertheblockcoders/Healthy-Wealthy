import React from 'react'
import Contact from '../Component/Contact'

const contact = () => {
  return (
    <div>
        <Contact/>
    </div>
  )
}

export default contact