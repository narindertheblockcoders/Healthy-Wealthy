import React from 'react'
import InvestPage from '../Component/InvestPage'

const investPage = () => {
  return (
    <div>
        <InvestPage/>
    </div>
  )
}

export default investPage